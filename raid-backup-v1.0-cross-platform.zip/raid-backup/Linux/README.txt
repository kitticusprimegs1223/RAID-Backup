Run: chmod +x raid-backup.sh && ./raid-backup.sh
Python 3 required.
