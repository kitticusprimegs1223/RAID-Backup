#!/usr/bin/env python3
import os, shutil, hashlib, json, datetime, pathlib, subprocess, sys

BASE=pathlib.Path.home()/".raid-diognostics2"; BACKUPS=BASE/"backups"; REPORTS=BASE/"reports"
BACKUPS.mkdir(parents=True,exist_ok=True); REPORTS.mkdir(parents=True,exist_ok=True)

def pause(): input("\nPress Enter to continue...")
def yes(s): return input(s+" Type YES to continue: ").strip()=="YES"
def size(p):
    p=pathlib.Path(p); return p.stat().st_size if p.is_file() else sum(x.stat().st_size for x in p.rglob("*") if x.is_file())
def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()
def manifest(root):
    root=pathlib.Path(root).resolve(); rows=[]
    for f in root.rglob("*"):
        if f.is_file() and f.name!="manifest.json":
            rows.append({"path":str(f.relative_to(root)),"size":f.stat().st_size,"sha256":sha(f)})
    (root/"manifest.json").write_text(json.dumps(rows,indent=2),encoding="utf-8")
def create():
    src=pathlib.Path(input("Source file or folder: ").strip()).expanduser()
    if not src.exists(): print("Source not found."); return
    dest=input(f"Destination [{BACKUPS}]: ").strip() or str(BACKUPS)
    target=pathlib.Path(dest).expanduser()/("backup-"+datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
    target.mkdir(parents=True)
    dst=target/src.name
    try:
        if src.is_dir(): shutil.copytree(src,dst)
        else: shutil.copy2(src,dst)
        (target/"backup.json").write_text(json.dumps({"source":str(src.resolve()),"created":datetime.datetime.now().isoformat(),"destination":str(target),"size":size(target)},indent=2))
        manifest(target); print("Backup completed:",target)
    except Exception as e: print("Backup failed:",e)
def browse():
    items=[x for x in BACKUPS.iterdir() if x.is_dir()]
    if not items: print("No backups found."); return
    for x in items: print(f"{x.name}  {size(x):,} bytes  {x}")
def verify():
    p=pathlib.Path(input("Backup folder: ").strip()).expanduser()
    m=p/"manifest.json"
    if not m.exists(): print("No manifest found."); return
    good=bad=0
    for row in json.loads(m.read_text(encoding="utf-8")):
        f=p/row["path"]
        if not f.exists(): print("MISSING:",row["path"]); bad+=1; continue
        if f.stat().st_size==row["size"] and sha(f)==row["sha256"]: good+=1
        else: print("FAILED:",row["path"]); bad+=1
    print(f"Verified: {good}  Failed/Missing: {bad}")
def restore():
    src=pathlib.Path(input("Backup folder: ").strip()).expanduser()
    dest=pathlib.Path(input("Restore destination: ").strip()).expanduser()
    if not src.is_dir(): print("Backup not found."); return
    if not yes("Restore may create or replace files in the destination."): return
    dest.mkdir(parents=True,exist_ok=True)
    for x in src.iterdir():
        if x.name in ("manifest.json","backup.json"): continue
        try:
            if x.is_dir(): shutil.copytree(x,dest/x.name,dirs_exist_ok=True)
            else: shutil.copy2(x,dest/x.name)
        except Exception as e: print("Failed:",x,e)
    print("Restore completed.")
def usb():
    candidates=[]
    if sys.platform=="darwin":
        v=pathlib.Path("/Volumes"); candidates=[x for x in v.iterdir() if x.is_dir()] if v.exists() else []
    else:
        roots=[pathlib.Path("/media")/pathlib.Path(os.environ.get("USER","")),pathlib.Path("/run/media")/pathlib.Path(os.environ.get("USER",""))]
        for r in roots:
            if r.exists(): candidates += [x for x in r.iterdir() if x.is_dir()]
    print("Possible removable drives:")
    for i,x in enumerate(candidates,1): print(i,x)
    if not candidates: print("No removable drive detected."); return
    try: d=candidates[int(input("Choose number: "))-1]
    except: return
    src=pathlib.Path(input("Source file or folder: ").strip()).expanduser()
    if not src.exists(): print("Source not found."); return
    target=d/"raid-diognostics2-backups"/("backup-"+datetime.datetime.now().strftime("%Y%m%d-%H%M%S")); target.mkdir(parents=True)
    try:
        if src.is_dir(): shutil.copytree(src,target/src.name)
        else: shutil.copy2(src,target/src.name)
        manifest(target); print("USB backup completed:",target)
    except Exception as e: print("USB backup failed:",e)
def report():
    p=REPORTS/("raid-backup-"+datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+".txt")
    lines=["RAID-BACKUP REPORT",f"Generated: {datetime.datetime.now()}",f"Backup root: {BACKUPS}"]
    for x in BACKUPS.iterdir():
        if x.is_dir(): lines.append(f"{x.name} - {size(x)} bytes - {x}")
    p.write_text("\n".join(lines),encoding="utf-8"); print("Report saved:",p)
def settings():
    print("Default backup location:",BACKUPS); print("Reports:",REPORTS)
    print("Verification: SHA-256 manifest"); print("Formatting/wiping: NEVER performed")
def main():
    actions={"1":create,"2":restore,"3":browse,"4":verify,"5":usb,"6":report,"7":settings}
    while True:
        print("\n"+"="*46+"\n RAID-BACKUP — BACKUP & RESTORE\n"+"="*46)
        print("[1] Create Backup\n[2] Restore Backup\n[3] Browse Backups\n[4] Verify Backup\n[5] Create USB Backup\n[6] Backup Report\n[7] Backup Settings\n[0] Exit")
        c=input("\nSelect: ").strip()
        if c=="0": break
        if c in actions: actions[c]()
        else: print("Invalid choice.")
        pause()
if __name__=="__main__": main()
