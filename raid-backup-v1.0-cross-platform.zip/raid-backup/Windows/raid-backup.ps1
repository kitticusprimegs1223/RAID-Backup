param()

$ErrorActionPreference = "Continue"
$Base = Join-Path $HOME "raid-diognostics2"
$Backups = Join-Path $Base "backups"
$Reports = Join-Path $Base "reports"
New-Item -ItemType Directory -Force -Path $Backups,$Reports | Out-Null

function Pause-App { Read-Host "`nPress Enter to continue" | Out-Null }
function Confirm-Yes($Message) {
    $x = Read-Host "$Message Type YES to continue"
    return $x -ceq "YES"
}
function Size-Bytes($Path) {
    if (Test-Path $Path -PathType Leaf) { return (Get-Item $Path).Length }
    $sum = 0
    Get-ChildItem -LiteralPath $Path -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object { $sum += $_.Length }
    return $sum
}
function New-Manifest($Root, $ManifestPath) {
    $base = (Resolve-Path $Root).Path
    $rows = Get-ChildItem -LiteralPath $base -Recurse -File -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -ne $ManifestPath } |
        ForEach-Object {
            $rel = $_.FullName.Substring($base.Length).TrimStart('\')
            $hash = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash
            "$rel`t$($_.Length)`t$hash"
        }
    Set-Content -LiteralPath $ManifestPath -Value $rows -Encoding UTF8
}
function Create-Backup {
    Write-Host "`n=== CREATE BACKUP ==="
    $src = Read-Host "Source file or folder"
    if (!(Test-Path $src)) { Write-Host "Source not found."; return }
    $dest = Read-Host "Destination [$Backups]"
    if ([string]::IsNullOrWhiteSpace($dest)) { $dest = $Backups }
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $target = Join-Path $dest "backup-$stamp"
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    $name = Split-Path $src -Leaf
    $copyTo = Join-Path $target $name
    if ((Get-Item $src).PSIsContainer) {
        robocopy $src $copyTo /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XJ /NP
        $ok = $LASTEXITCODE -lt 8
    } else {
        Copy-Item -LiteralPath $src -Destination $copyTo -Force
        $ok = $?
    }
    if ($ok) {
        $manifest = Join-Path $target "manifest.tsv"
        New-Manifest $target $manifest
        [ordered]@{Source=(Resolve-Path $src).Path;Created=(Get-Date).ToString("o");Destination=$target;SizeBytes=(Size-Bytes $target)} |
            ConvertTo-Json | Set-Content (Join-Path $target "backup.json") -Encoding UTF8
        Write-Host "Backup completed: $target"
    } else { Write-Host "Backup failed." }
}
function Browse-Backups {
    Write-Host "`n=== AVAILABLE BACKUPS ==="
    $items = Get-ChildItem $Backups -Directory -ErrorAction SilentlyContinue
    if (!$items) { Write-Host "No backups found."; return }
    $items | ForEach-Object {
        $size = Size-Bytes $_.FullName
        "{0,-28} {1,12:N0} bytes  {2}" -f $_.Name,$size,$_.FullName
    }
}
function Verify-Backup {
    $path = Read-Host "Backup folder"
    if (!(Test-Path $path -PathType Container)) { Write-Host "Backup folder not found."; return }
    $manifest = Join-Path $path "manifest.tsv"
    if (!(Test-Path $manifest)) {
        Write-Host "No manifest found. Running readability check instead."
        $files = Get-ChildItem $path -Recurse -File -Force
        Write-Host "Files present: $($files.Count)"
        return
    }
    $good=0; $bad=0
    Get-Content $manifest | ForEach-Object {
        $parts = $_ -split "`t",3
        if ($parts.Count -lt 3) { return }
        $file = Join-Path $path $parts[0]
        if (!(Test-Path $file -PathType Leaf)) { Write-Host "MISSING: $($parts[0])"; $bad++; return }
        $item = Get-Item $file
        $hash = (Get-FileHash $file -Algorithm SHA256).Hash
        if ($item.Length -eq [int64]$parts[1] -and $hash -eq $parts[2]) { $good++ }
        else { Write-Host "FAILED: $($parts[0])"; $bad++ }
    }
    Write-Host "`nVerified: $good  Failed/Missing: $bad"
}
function Restore-Backup {
    $src = Read-Host "Backup folder"
    if (!(Test-Path $src -PathType Container)) { Write-Host "Backup not found."; return }
    $dest = Read-Host "Restore destination"
    if ([string]::IsNullOrWhiteSpace($dest)) { return }
    Write-Host "`nContents to restore:"
    Get-ChildItem $src -Force | Where-Object Name -notin @("manifest.tsv","backup.json") | Select-Object Name,Length,LastWriteTime | Format-Table -AutoSize
    if (!(Confirm-Yes "Restore may create or replace files in the destination.")) { Write-Host "Cancelled."; return }
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    Get-ChildItem $src -Force | Where-Object Name -notin @("manifest.tsv","backup.json") | ForEach-Object {
        if ($_.PSIsContainer) { robocopy $_.FullName (Join-Path $dest $_.Name) /E /COPY:DAT /R:1 /W:1 /XJ /NP | Out-Null }
        else { Copy-Item $_.FullName (Join-Path $dest $_.Name) -Force }
    }
    Write-Host "Restore completed."
}
function USB-Backup {
    Write-Host "`n=== USB BACKUP ==="
    $vols = Get-Volume | Where-Object DriveLetter -and ($_.DriveType -eq "Removable")
    if (!$vols) { Write-Host "No removable USB drive detected."; return }
    $i=1; $map=@{}
    foreach($v in $vols) { Write-Host "[$i] $($v.DriveLetter): $($v.FileSystemLabel) $([math]::Round($v.Size/1GB,2)) GB"; $map[$i]=$v; $i++ }
    $n = Read-Host "Choose USB number"
    if (!$map.ContainsKey([int]$n)) { return }
    $src = Read-Host "Source file or folder"
    if (!(Test-Path $src)) { Write-Host "Source not found."; return }
    $usb = "$($map[[int]$n].DriveLetter):\raid-diognostics2-backups"
    New-Item -ItemType Directory -Force -Path $usb | Out-Null
    $stamp=Get-Date -Format "yyyyMMdd-HHmmss"
    $target=Join-Path $usb "backup-$stamp"
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    $name=Split-Path $src -Leaf
    if ((Get-Item $src).PSIsContainer) { robocopy $src (Join-Path $target $name) /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XJ /NP | Out-Null }
    else { Copy-Item $src (Join-Path $target $name) -Force }
    New-Manifest $target (Join-Path $target "manifest.tsv")
    Write-Host "USB backup completed: $target"
}
function Report {
    $file=Join-Path $Reports ("raid-backup-"+(Get-Date -Format "yyyyMMdd-HHmmss")+".txt")
    $text=@("RAID-BACKUP REPORT","Generated: $(Get-Date)","Backup root: $Backups","")
    $items=Get-ChildItem $Backups -Directory -ErrorAction SilentlyContinue
    foreach($x in $items) { $text += "$($x.Name) - $(Size-Bytes $x.FullName) bytes - $($x.FullName)" }
    $text | Set-Content $file -Encoding UTF8
    Write-Host "Report saved: $file"
}
function Settings {
    Write-Host "`nDefault backup location: $Backups"
    Write-Host "Reports: $Reports"
    Write-Host "Verification: SHA-256 manifest"
    Write-Host "Compression: OFF by default (folder backup preserves files directly)"
    Write-Host "Formatting/wiping: NEVER performed"
}
function Main {
while($true) {
Clear-Host
Write-Host "==============================================="
Write-Host "                 RAID-BACKUP"
Write-Host "          BACKUP & RESTORE UTILITY"
Write-Host "==============================================="
Write-Host "[1] Create Backup"
Write-Host "[2] Restore Backup"
Write-Host "[3] Browse Backups"
Write-Host "[4] Verify Backup"
Write-Host "[5] Create USB Backup"
Write-Host "[6] Backup Report"
Write-Host "[7] Backup Settings"
Write-Host "[0] Exit"
$c=Read-Host "`nSelect"
switch($c) {
"1"{Create-Backup;Pause-App};"2"{Restore-Backup;Pause-App};"3"{Browse-Backups;Pause-App};"4"{Verify-Backup;Pause-App};"5"{USB-Backup;Pause-App};"6"{Report;Pause-App};"7"{Settings;Pause-App};"0"{return}
default{Write-Host "Invalid choice.";Pause-App}
}}
}
Main
